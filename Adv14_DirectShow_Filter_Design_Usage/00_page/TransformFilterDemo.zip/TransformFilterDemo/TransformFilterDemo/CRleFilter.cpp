// MFC Dll: ms-help://MS.MSDNQTR.2006JAN.1033/vccore/html/_core_initialize_a_dll.htm
// ms-help://MS.MSSDK.1033/MS.WinSDK.1033/directshow/htm/step6addsupportforcom.htm

// DirectX �춥�о� -- DirectShow Transform filter �g�@�d��
// 																	-- ������
// BaseClass �M�׳]�w
//   - Additional Include Directories: .;"$(DXSDK_DIR)Include";"$(WSDK_DIR)Windows\v6.0\Include"
//   - Additional Library Directories: "$(DXSDK_DIR)Lib\x86";..\lib
//   - Librarian -> Command Lin -> Additional options: /nodefaultlib 

// TransformFilterDemo �M�׳]�w
//   - �[�J library: strmbasd.lib Winmm.lib Quartz.lib strmiids.lib
//   - Additional Include Directories: "$(WSDK_DIR)Windows\v6.0\Include";"$(DXSDK_DIR)Include";.\;..\BaseClasses
//   - Additional Library Directories: "$(WSDK_DIR)Windows\v6.0\Lib";..\..\DirectShowRenderEngine\lib;..\BaseClasses\Debug;


#include "stdafx.h"

#define CRleFilterExport
#include "CRleFilter.h"



CRleFilter::CRleFilter()
  : CTransformFilter(NAME("My RLE Encoder"), 0, CLSID_RLEFilter)
{ 
   /* Initialize any private variables here. */
}

// ���ҬO�_�n�����O�H���s�u: (�� upstream filter �n�D�s�u��, �I�s�o�� method ���ҥثe media type)
HRESULT CRleFilter::CheckInputType(const CMediaType *mtIn){
	// �ڭ̦b�o���ˬd�O�_�n���� upstream ���s�u

	// Step 1: �ˬd  major type and subtype 
    if ((mtIn->majortype != MEDIATYPE_Video) ||
        (mtIn->subtype != MEDIASUBTYPE_RGB8) ||
        (mtIn->formattype != FORMAT_VideoInfo) || 
        (mtIn->cbFormat < sizeof(VIDEOINFOHEADER)))    {
        return VFW_E_TYPE_NOT_ACCEPTED; // ���O�ڭ̱����� type, �^�Ǥ������s�u
    }

	// Step 2: �ˬd�ثe media �O�_�� 8-bit �����Y RGB ���A
    VIDEOINFOHEADER *pVih = 
        reinterpret_cast<VIDEOINFOHEADER*>(mtIn->pbFormat);
    if ((pVih->bmiHeader.biBitCount != 8) || (pVih->bmiHeader.biCompression != BI_RGB)) {
        return VFW_E_TYPE_NOT_ACCEPTED;
    }

    // Step 3: �ˬd�զ�L
    if (pVih->bmiHeader.biClrUsed > PALETTE_ENTRIES(pVih)){
        return VFW_E_TYPE_NOT_ACCEPTED;
    }
    DWORD cbPalette = pVih->bmiHeader.biClrUsed * sizeof(RGBQUAD);
    if (mtIn->cbFormat < sizeof(VIDEOINFOHEADER) + cbPalette)  {
        return VFW_E_TYPE_NOT_ACCEPTED;
    }

    // Step 4: Everything is good.
    return S_OK;
}

// ���ѧڭ̿�X�� media type
HRESULT CRleFilter::GetMediaType(int iPosition, CMediaType *pMediaType){
    ASSERT(m_pInput->IsConnected());
    if (iPosition < 0) {
        return E_INVALIDARG;
    }

    if (iPosition == 0) {
		// Step 1: ���o input pin �s�u�ҥΪ� media type (�ثe�]�p���Ǧ^ input media type)
        HRESULT hr = m_pInput->ConnectionMediaType(pMediaType);
        if (FAILED(hr))    {
            return hr;
        }

		// Step 2: �w�q�s�� FourCC code ���ڭ̪� RLE codec
        FOURCCMap fccMap = FCC('MRLE'); 
        pMediaType->subtype = static_cast<GUID>(fccMap);

		// Step 3: �Хܧڭ̪� media sample �O variable-sized samples
        pMediaType->SetVariableSize();
        pMediaType->SetTemporalCompression(FALSE); // �i���ڭ̨C�@�i frame ���O key frame. (This field is informational only, so you could safely ignore it.)

		// Step 4: �]�w media sample �����A
        ASSERT(pMediaType->formattype == FORMAT_VideoInfo); // �P input pin �s�u�� media type �@�w�n�O video
        VIDEOINFOHEADER *pVih =reinterpret_cast<VIDEOINFOHEADER*>(pMediaType->pbFormat);
        pVih->bmiHeader.biCompression = BI_RLE8;//  �ק� biCompression �� BI_RLE8 �����Y�Φ�
        pVih->bmiHeader.biSizeImage = DIBSIZE(pVih->bmiHeader); // �]�w�ثe���Y�]�w�U, �@�i�ϩһݭn�� bytes ��
        return S_OK;
    }
    // else
    return VFW_S_NO_MORE_ITEMS;
}


// �Ǧ^ S_OK ���ܧڭ̦P�ɱ��� Input �P Output media types 
HRESULT CRleFilter::CheckTransform(const CMediaType *mtIn, const CMediaType *mtOut){
    // Step 1: �ˬd��X�� majortype == MEDIATYPE_Video
    if (mtOut->majortype != MEDIATYPE_Video)    {
        return VFW_E_TYPE_NOT_ACCEPTED;
    }

    // Step 2: �ˬd��X�O�_��
	//         a. subtype == MRLE
	//         b. formattype == FORMAT_VideoInfo
    FOURCCMap fccMap = FCC('MRLE'); 
    if (mtOut->subtype != static_cast<GUID>(fccMap))    {
        return VFW_E_TYPE_NOT_ACCEPTED;
    }
    if ((mtOut->formattype != FORMAT_VideoInfo) || (mtOut->cbFormat < sizeof(VIDEOINFOHEADER)))  {
        return VFW_E_TYPE_NOT_ACCEPTED;
    }

    // Step 3: �ˬd��J Pin �P ��X Pin �� Width �P Height �O�_�@��
    ASSERT(mtIn->formattype == FORMAT_VideoInfo);
    BITMAPINFOHEADER *pBmiOut = HEADER(mtOut->pbFormat);
    BITMAPINFOHEADER *pBmiIn = HEADER(mtIn->pbFormat);
    if ((pBmiOut->biPlanes != 1) ||
        (pBmiOut->biBitCount != 8) ||
        (pBmiOut->biCompression != BI_RLE8) ||
        (pBmiOut->biWidth != pBmiIn->biWidth) ||
        (pBmiOut->biHeight != pBmiIn->biHeight))
    {
        return VFW_E_TYPE_NOT_ACCEPTED;
    }

    // Compare source and target rectangles.
    RECT rcImg;
    SetRect(&rcImg, 0, 0, pBmiIn->biWidth, pBmiIn->biHeight);
    RECT *prcSrc = &((VIDEOINFOHEADER*)(mtIn->pbFormat))->rcSource;
    RECT *prcTarget = &((VIDEOINFOHEADER*)(mtOut->pbFormat))->rcTarget;
    if (!IsRectEmpty(prcSrc) && !EqualRect(prcSrc, &rcImg))    {
        return VFW_E_INVALIDMEDIATYPE;
    }
    if (!IsRectEmpty(prcTarget) && !EqualRect(prcTarget, &rcImg))    {
        return VFW_E_INVALIDMEDIATYPE;
    }

    // Check the palette table.
    if (pBmiOut->biClrUsed != pBmiIn->biClrUsed)
    {
        return VFW_E_TYPE_NOT_ACCEPTED;
    }
    DWORD cbPalette = pBmiOut->biClrUsed * sizeof(RGBQUAD);
    if (mtOut->cbFormat < sizeof(VIDEOINFOHEADER) + cbPalette)    {
        return VFW_E_TYPE_NOT_ACCEPTED;
    }
    if (0 != memcmp(pBmiOut + 1, pBmiIn + 1, cbPalette))   {
        return VFW_E_TYPE_NOT_ACCEPTED;
    }

    // Everything is good.
    return S_OK;
}

// �]�w�o�� filter ��X pin �� buffer allocator �ݩ�
// pAlloc = ��X pin �� buffer allocator
// pProp = �ΨӻP downstream ���q�� buffer �ݨD
HRESULT CRleFilter::DecideBufferSize(IMemAllocator *pAlloc, ALLOCATOR_PROPERTIES *pProp){

	// Step 1: ���o��X Pin media type ���ƻs�~
    AM_MEDIA_TYPE mt;
    HRESULT hr = m_pOutput->ConnectionMediaType(&mt);
    if (FAILED(hr)) {
        return hr;
    }
    ASSERT(mt.formattype == FORMAT_VideoInfo); // �T�w�ثe�B�z�� media type �O FORMAT_VideoInfo 

	// Step 2: �]�w ���q buffer �ݨD
    BITMAPINFOHEADER *pbmi = HEADER(mt.pbFormat); // �Ǧ^��XPin�� BITMAPINFOHEADER ����}
    pProp->cbBuffer = DIBSIZE(*pbmi) * 2; // �]�w�ݭn���Ŷ��� 2 ����DIB �v��size (bytes)
    if (pProp->cbAlign == 0)    {
        pProp->cbAlign = 1;
    }
    if (pProp->cBuffers == 0)    {
        pProp->cBuffers = 1;
    }

    // Step 4: Release the format block.
    FreeMediaType(mt);

    // Step 5: �N��X Pin �� buffer allocator �]�w�� pProp
    ALLOCATOR_PROPERTIES Actual; // �]�w��, �t�ι�ڰt�m�����p
    hr = pAlloc->SetProperties(pProp, &Actual);
    if (FAILED(hr))  {
        return hr;
    }
    // �ˬd��ڰt�m�����G, �O�_���T
    if (pProp->cbBuffer > Actual.cbBuffer) {
        return E_FAIL;
    }
    return S_OK;
}

// �i��B�z
// �^�ǭ�:
//  S_OK = �ثe filter �w�g�N sample �ǵ� downstream �F
//  S_FALSE = �o�� sample �w�g�Q skip ���F
HRESULT CRleFilter::Transform(IMediaSample *pSource, IMediaSample *pDest){
	HRESULT hr;
	// Step 1: ���o source buffer
    BYTE *pBufferIn, *pBufferOut;
    hr = pSource->GetPointer(&pBufferIn);
    if (FAILED(hr)) {
        return hr;
    }

	// Step 2: ���o destination buffer
    hr = pDest->GetPointer(&pBufferOut);
    if (FAILED(hr))   {
        return hr;
    }

	// Step 3: �B�z���
	long SourceLength=pSource->GetSize();
	long DestLength=pDest->GetSize();
	KASSERT(SourceLength==DestLength); // �ӷ��P�ت��@�w�n�@��, �_�h�۰ʸ��X exception
	for(long i=0;i<SourceLength;i++){
		*(pBufferOut+i)=*(pBufferIn+i);
	}

    pDest->SetActualDataLength(DestLength); // �]�w��ڪ���ƪ���
    // pDest->SetSyncPoint(TRUE);
    return S_OK;
}

// ���� COM �إ� CRleFilter ����
CUnknown * WINAPI CRleFilter::CreateInstance(LPUNKNOWN pUnk, HRESULT *pHr){
    CRleFilter *pFilter = new CRleFilter();
    if (pFilter== NULL)  {
        *pHr = E_OUTOFMEMORY;
    }
    return pFilter;
}

static WCHAR g_wszName[] = L"My RLE Encoder";
CFactoryTemplate g_Templates[] = 
{
  { 
    g_wszName,
    &CLSID_RLEFilter,
    CRleFilter::CreateInstance,
    NULL,
    NULL
  }
};

int g_cTemplates = sizeof(g_Templates) / sizeof(g_Templates[0]);  

// Declare media type information.
FOURCCMap fccMap = FCC('MRLE'); 
REGPINTYPES sudInputTypes = { &MEDIATYPE_Video, &GUID_NULL };
REGPINTYPES sudOutputTypes = { &MEDIATYPE_Video, (GUID*)&fccMap };

// Declare pin information.
REGFILTERPINS sudPinReg[] = {
    // Input pin.
    { 0, FALSE, // Rendered?
         FALSE, // Output?
         FALSE, // Zero?
         FALSE, // Many?
         0, 0, 
         1, &sudInputTypes  // Media types.
    },
    // Output pin.
    { 0, FALSE, // Rendered?
         TRUE, // Output?
         FALSE, // Zero?
         FALSE, // Many?
         0, 0, 
         1, &sudOutputTypes      // Media types.
    }
};

// Declare filter information.
REGFILTER2 rf2FilterReg = {
    1,                // Version number.
    MERIT_DO_NOT_USE, // Merit.
    2,                // Number of pins.
    sudPinReg         // Pointer to pin information.
};

STDAPI DllRegisterServer(void)
{
    HRESULT hr = AMovieDllRegisterServer2(TRUE);
    if (FAILED(hr))
    {
        return hr;
    }
    IFilterMapper2 *pFM2 = NULL;
    hr = CoCreateInstance(CLSID_FilterMapper2, NULL, CLSCTX_INPROC_SERVER,
            IID_IFilterMapper2, (void **)&pFM2);
    if (SUCCEEDED(hr))
    {
        hr = pFM2->RegisterFilter(
            CLSID_RLEFilter,                // Filter CLSID. 
            g_wszName,                       // Filter name.
            NULL,                            // Device moniker. 
            &CLSID_VideoCompressorCategory,  // Video compressor category.
            g_wszName,                       // Instance data.
            &rf2FilterReg                    // Filter information.
            );
        pFM2->Release();
    }
    return hr;
}

STDAPI DllUnregisterServer()
{
    HRESULT hr = AMovieDllRegisterServer2(FALSE);
    if (FAILED(hr))
    {
        return hr;
    }
    IFilterMapper2 *pFM2 = NULL;
    hr = CoCreateInstance(CLSID_FilterMapper2, NULL, CLSCTX_INPROC_SERVER,
            IID_IFilterMapper2, (void **)&pFM2);
    if (SUCCEEDED(hr))
    {
        hr = pFM2->UnregisterFilter(&CLSID_VideoCompressorCategory, 
            g_wszName, CLSID_RLEFilter);
        pFM2->Release();
    }
    return hr;
}

/*
extern "C" BOOL WINAPI DllEntryPoint(HINSTANCE, ULONG, LPVOID);
BOOL WINAPI DllMain(HANDLE hinstDLL,DWORD dwReason,LPVOID lpvReserved){
	  DllEntryPoint((HINSTANCE)hinstDLL,dwReason,lpvReserved);
}
*/

/*
STDAPI DllRegisterServer()
{
    return AMovieDllRegisterServer2( TRUE );
}
STDAPI DllUnregisterServer()
{
    return AMovieDllRegisterServer2( FALSE );
}
*/




