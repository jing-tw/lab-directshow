// TransformFilterDemo.h : main header file for the TransformFilterDemo DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CTransformFilterDemoApp
// See TransformFilterDemo.cpp for the implementation of this class
//

class CTransformFilterDemoApp : public CWinApp
{
public:
	CTransformFilterDemoApp();

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};
